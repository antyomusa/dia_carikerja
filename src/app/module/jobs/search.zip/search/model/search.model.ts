export class SearchModel {
    recentJobs: any = [];
}